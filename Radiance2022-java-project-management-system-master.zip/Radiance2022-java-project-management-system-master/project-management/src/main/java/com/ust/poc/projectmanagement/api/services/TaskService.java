package com.ust.poc.projectmanagement.api.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.poc.projectmanagement.api.entity.Project;
import com.ust.poc.projectmanagement.api.entity.Task;
import com.ust.poc.projectmanagement.api.repository.ProjectRepository;
import com.ust.poc.projectmanagement.api.repository.TaskRepository;

@Service
public class TaskService {

	@Autowired
	ProjectRepository projectRepository;

	@Autowired
	TaskRepository taskRepository;

	public Task createTask(Task task, int project_id) {
		Project project = projectRepository.findById(project_id).orElse(null);
		task.setProjects(project);
		return taskRepository.save(task);
	}

	public Task updateTask(Task updatedTask) {
		return taskRepository.save(updatedTask);
	}

	public void deleteTask(int id) {
		taskRepository.deleteById(id);
	}

	public void deleteAllTasks() {
		taskRepository.deleteAll();

	}
	public Task viewTask(int id) {
		return taskRepository.findById(id).orElse(null);
	}

	public List<Task> viewAllTasksWithProjectId(int project_id) {
		Project project = projectRepository.findById(project_id).orElse(null);
		return project.getTasks();

	}

	public List<Task> viewAllTasks() {
		return taskRepository.findAll();
	}

}
