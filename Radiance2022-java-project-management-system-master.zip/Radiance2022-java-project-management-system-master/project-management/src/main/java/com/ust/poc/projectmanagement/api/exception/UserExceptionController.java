package com.ust.poc.projectmanagement.api.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
public class UserExceptionController extends ResponseEntityExceptionHandler{
	
	@ExceptionHandler(value= UserNotfoundException.class)
	public ResponseEntity<Object> exception(UserNotfoundException exception)
	{
		return new ResponseEntity<Object>("User not found", HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value=InvalidCredentialsException.class)
	public ResponseEntity<Object> badException(InvalidCredentialsException exception)
	{
		return new ResponseEntity<Object>("Invalid username or password", HttpStatus.NON_AUTHORITATIVE_INFORMATION);
	}
	
	@ExceptionHandler(value=ConstraintViolationException.class)
	public ResponseEntity<Object> contraintException(ConstraintViolationException ex)
	{
		return new ResponseEntity<Object>("mandatory values are not provided",HttpStatus.BAD_REQUEST);
	}
}
