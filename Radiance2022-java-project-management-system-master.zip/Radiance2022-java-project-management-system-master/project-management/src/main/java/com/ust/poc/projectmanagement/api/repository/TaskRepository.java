package com.ust.poc.projectmanagement.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ust.poc.projectmanagement.api.entity.Task;

public interface TaskRepository extends JpaRepository<Task, Integer>{

}
