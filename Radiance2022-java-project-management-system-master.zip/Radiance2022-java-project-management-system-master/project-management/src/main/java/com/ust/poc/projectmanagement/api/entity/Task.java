package com.ust.poc.projectmanagement.api.entity;

import java.util.Date;
import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;

@Data // @Getter @Setter @RequiredArgsConstructor @EqualsAndHashCode
@Entity
@Table(name = "task")
public class Task {

	@Id
	@GeneratedValue
	private int id;

	@Column(name = "title", nullable = false, unique = true)
	private String title;

	@NotBlank(message = "Task priority is mandatory")
	@Column(name = "priority", nullable = false)
	private String priority;

	@Column(name = "startDate", nullable = false)
	private Date startDate;

	@Column(name = "estimatedDate", nullable = true)
	private Date estimatedDate;

	@Column(name = "status", nullable = true)
	private String status;

	@Getter(AccessLevel.NONE)
	@ManyToOne()
	@JoinColumn(name = "project_fk_id")
	private Project projects;

	public int getProjectId() {
		return projects.getId();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEstimatedDate() {
		return estimatedDate;
	}

	public void setEstimatedDate(Date estimatedDate) {
		this.estimatedDate = estimatedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Project getProjects() {
		return projects;
	}

	public void setProjects(Project projects) {
		this.projects = projects;
	}

}