package com.ust.poc.projectmanagement.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ust.poc.projectmanagement.api.entity.Project;

public interface ProjectRepository extends JpaRepository<Project, Integer> {

	public List<Project> findByIsActive(boolean isActive);

	public List<Project> findByStatus(String status);

}