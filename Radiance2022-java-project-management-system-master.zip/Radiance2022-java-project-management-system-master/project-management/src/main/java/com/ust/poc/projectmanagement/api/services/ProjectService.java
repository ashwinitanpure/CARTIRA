package com.ust.poc.projectmanagement.api.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.poc.projectmanagement.api.entity.Project;
import com.ust.poc.projectmanagement.api.repository.ProjectRepository;

@Service
public class ProjectService {

	@Autowired
	ProjectRepository projectRepository;
	
	public Project createProject(Project project) {
		return projectRepository.save(project);
	}
	public Project updateProject(Project updatedProject) {
		return projectRepository.save(updatedProject);
	}
	public void deleteProject(int id) {
		projectRepository.deleteById(id);
	}
	public void deleteAllProjects() {
		projectRepository.deleteAll();
	}
	public Project viewProjectById(int id) {
		return projectRepository.findById(id).orElse(null);
	}
	public List<Project> viewAllProjects() {
		return (List<Project>)projectRepository.findAll();
	}
	
	public List<Project> onGoingProjects(){
		return projectRepository.findByIsActive(true);
	}
	
	public List<Project> completedProjects(){
		return projectRepository.findByStatus("completed");
	}
	public List<Project> pendingProjects(){
		return projectRepository.findByStatus("pending");
	}
	
	
}
