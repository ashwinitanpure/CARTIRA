package com.ust.poc.projectmanagement.api.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.ust.poc.projectmanagement.api.dto.UserDto;


public class PasswordEqualConstraintValidator implements ConstraintValidator<PasswordEqualValidator, Object>{

	@Override
	public boolean isValid(Object user, ConstraintValidatorContext context) {
		UserDto u=(UserDto) user;
		//User u1=(User) user;
		
		return u.getPassword().equals(u.getRepeatPassword());
		
	}

}
