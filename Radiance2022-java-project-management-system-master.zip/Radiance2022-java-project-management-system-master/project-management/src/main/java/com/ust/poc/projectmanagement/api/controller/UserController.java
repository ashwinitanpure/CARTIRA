package com.ust.poc.projectmanagement.api.controller;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validator;


import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.poc.projectmanagement.api.dto.UserDto;
import com.ust.poc.projectmanagement.api.entity.User;
import com.ust.poc.projectmanagement.api.exception.ConstraintViolationException;
import com.ust.poc.projectmanagement.api.exception.UserAlreadyExistAuthenticationException;
import com.ust.poc.projectmanagement.api.service.UserService;



@RestController
@RequestMapping("/project-management")
public class UserController {
	
	private static final org.slf4j.Logger log =LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private Validator validator; 
	
	@PostMapping("/user")
	public ResponseEntity<UserDto> create(@Valid @RequestBody UserDto userDto) throws UserAlreadyExistAuthenticationException
	{
		Set<ConstraintViolation<UserDto>> violations= validator.validate(userDto);
		
		if(!violations.isEmpty()) {
			log.error("mandatory values are not provided ");
			log.warn("name-mandatory, email-email format, password- 1 uppercase&1lowercase&1digit&no whitespace");
			throw new ConstraintViolationException();
		}
		else{
			
			List<User> users = userService.viewAllUsers();
	        for(User u : users)
	        {
	            if(userDto.getEmailId().equals(u.getEmailId()))
	            {
	                throw new UserAlreadyExistAuthenticationException("User already exists with " + userDto.getEmailId());
	            }
	        }
			
		userService.createUser(userDto);
		log.info("User created with email ID "+ userDto.getEmailId());
		return ResponseEntity.status(HttpStatus.CREATED).body(userDto);
		}
	}
	
	
	//2 login API are added for role based testing purpose.
	// after merging the other API only one login API(/login) will be available
	
	@GetMapping("/login")
	@Secured("ROLE_USER")
	public String login()
	{
		return "Welcome User";
	}
	
	@GetMapping("/manager/login")
	@Secured("ROLE_MANAGER")
	//@PreAuthorize("hasRole(ROLE_manager)")
	public String login1()
	{
		return "Welcome Manager";
	}

}
