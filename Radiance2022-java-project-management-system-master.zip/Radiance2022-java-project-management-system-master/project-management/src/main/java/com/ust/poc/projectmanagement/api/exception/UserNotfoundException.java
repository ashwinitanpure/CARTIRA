package com.ust.poc.projectmanagement.api.exception;

public class UserNotfoundException extends RuntimeException{

}
