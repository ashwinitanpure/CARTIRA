package com.ust.poc.projectmanagement.api.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

import com.ust.poc.projectmanagement.api.validation.PasswordEqualValidator;
import com.ust.poc.projectmanagement.api.validation.ValidPassword;

@PasswordEqualValidator(message="passwords are not equal")
public class UserDto {
	
	@NotBlank(message="user name is mandatory")
	private String name;
	
	@NotBlank(message = "email id is mandatory")
	@Email
	private String emailId;
	
	@ValidPassword(message="valid password is needed")
	private String password;
	
	
	private String repeatPassword;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRepeatPassword() {
		return repeatPassword;
	}

	public void setRepeatPassword(String repeatPassword) {
		this.repeatPassword = repeatPassword;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	
	

}
