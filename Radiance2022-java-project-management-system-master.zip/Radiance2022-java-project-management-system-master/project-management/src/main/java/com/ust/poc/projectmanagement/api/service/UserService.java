package com.ust.poc.projectmanagement.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.ust.poc.projectmanagement.api.dto.UserDto;
import com.ust.poc.projectmanagement.api.entity.User;
import com.ust.poc.projectmanagement.api.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepo;

	public void createUser(UserDto userDto)
	{
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(userDto.getPassword());
		
		User user=new User(); 
		
		user.setName(userDto.getName());
		user.setEmailId(userDto.getEmailId());
		user.setPassword(encodedPassword);
		user.setRole("USER");
		
		userRepo.save(user);
	}

	public List<User> viewAllUsers() {
		return userRepo.findAll();
	}

	
	
}
