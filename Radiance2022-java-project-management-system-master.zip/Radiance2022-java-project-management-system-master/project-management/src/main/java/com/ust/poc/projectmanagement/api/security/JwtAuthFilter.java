package com.ust.poc.projectmanagement.api.security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.ust.poc.projectmanagement.api.jwt.helper.JwtOperations;
import com.ust.poc.projectmanagement.api.service.CustomUserDetails;


@Component
public class JwtAuthFilter extends OncePerRequestFilter{
	
	private static final org.slf4j.Logger log =LoggerFactory.getLogger(JwtAuthFilter.class);
	
	@Autowired
	private CustomUserDetails customUserService;
	@Autowired
	private JwtOperations jwtOperations;
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
			
		//get jwt and validate
		
		String authorization= request.getHeader("Authorization");
		
		String username=null;
		String jwtToken=null;
		
		if(authorization !=null && authorization.startsWith("Token "))
		{
			jwtToken=authorization.substring(6);
			
			try {
				username=this.jwtOperations.extractUsername(jwtToken);
			}
			catch(Exception e)
			{
				log.error("user doesn't exist with provided token");
			}
			
			
			//validate 
			
			UserDetails userDeatils=this.customUserService.loadUserByUsername(username);
			
			if(username !=null && SecurityContextHolder.getContext().getAuthentication()==null)
			{
				UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken=new UsernamePasswordAuthenticationToken(userDeatils, null, userDeatils.getAuthorities());
				
				usernamePasswordAuthenticationToken.setDetails(usernamePasswordAuthenticationToken);
				
				SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
				
				
			}
			else
			{
				log.error("invalid Token");;
			}
			
			
		}
		
		filterChain.doFilter(request, response);
	}

}
