package com.ust.poc.projectmanagement.api.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.ust.poc.projectmanagement.api.entity.User;
import com.ust.poc.projectmanagement.api.exception.UserNotfoundException;
import com.ust.poc.projectmanagement.api.repository.UserRepository;

@Service
public class CustomUserDetails implements UserDetailsService {

	private static final org.slf4j.Logger log = LoggerFactory.getLogger(CustomUserDetails.class);

	@Autowired
	private UserRepository userRepo;

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		User user = userRepo.findByEmailId(email);
		if (user == null) {
			log.error("user not found with email " , email);
			throw new UserNotfoundException();
		}

		Set<SimpleGrantedAuthority> authorities = new HashSet<>();

		authorities.add(new SimpleGrantedAuthority("ROLE_" + user.getRole().toUpperCase()));

		return new org.springframework.security.core.userdetails.User(user.getEmailId(), user.getPassword(),
				authorities);

	}

}
