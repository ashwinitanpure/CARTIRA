package com.ust.poc.projectmanagement.api.controller;

import java.util.List;
import java.util.NoSuchElementException;

import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.poc.projectmanagement.api.entity.Project;
import com.ust.poc.projectmanagement.api.entity.Task;
import com.ust.poc.projectmanagement.api.exception.DataIntegrityViolationException;
import com.ust.poc.projectmanagement.api.services.TaskService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/task")
@Slf4j
public class TaskController {
	private static final org.slf4j.Logger log =LoggerFactory.getLogger(JwtController.class);

	@Autowired
	TaskService taskService;

	@PostMapping("/{project_id}")
	@Secured("ROLE_MANAGER")
	public ResponseEntity<Task> createTask(@Valid @RequestBody Task task, @PathVariable("project_id") int project_id) {
		
		List<Task> persistedTasks = taskService.viewAllTasks();
		
		for (Task t : persistedTasks) {
			if (task.getProjectId() == t.getProjectId() && task.getTitle().equals(t.getTitle())) {
				log.error("exception as duplicate task exist in same project");
				throw new DataIntegrityViolationException("Task already exists in given project");
			} 
		}
			log.info("Creating task for project with id = {} ", project_id);

			Task persistedTask = taskService.createTask(task, project_id);
			log.info("Task for project with id = {} created successfully.", persistedTask.getId());
			return new ResponseEntity<>(persistedTask, HttpStatus.CREATED);
	}

	@GetMapping("/{id}")
	@Secured({"ROLE_MANAGER","ROLE_USER"})
	public ResponseEntity<Task> viewTask(@PathVariable("id") int id) {
		log.info("Fetching task with id = {}", id);
		Task persistedTask = taskService.viewTask(id);

		if (persistedTask != null) {
			log.info("Task fetched successfully with task id = {}", id);
			return new ResponseEntity<>(persistedTask, HttpStatus.OK);
		} else {
			throw new NoSuchElementException("No task found with id : " + id);
		}
	}
	
	@GetMapping("/list")
	@Secured({"ROLE_MANAGER","ROLE_USER"})
	public ResponseEntity<List<Task>> viewAllTasks() {
		log.info("Fetching all tasks...");
		List<Task> persistedTask = taskService.viewAllTasks();

		if (persistedTask.isEmpty()) {
			throw new NoSuchElementException("No tasks exist in database!!! ");
		} else {
			return new ResponseEntity<>(persistedTask, HttpStatus.OK);
		}
	}

	@PutMapping("/{id}")
	@Secured({"ROLE_MANAGER","ROLE_USER"})
	public ResponseEntity<Task> updateTask(@Valid @RequestBody Task task, @PathVariable("id") int id) {
		
		log.info("Updating task with task id = {}", task.getId());
		Task persistedTask = taskService.viewTask(id);

		if (persistedTask != null) {
			persistedTask = taskService.updateTask(task);
			log.info("Task with id {} updated successfully.", persistedTask.getId());
			return new ResponseEntity<>(persistedTask, HttpStatus.OK);
		} else {
			throw new NoSuchElementException("Task does not exist...");
		}
	}

	@DeleteMapping("/{id}")
	@Secured("ROLE_MANAGER")
	public ResponseEntity<Void> deleteTask(@PathVariable("id") int id) {
		int deleted_id = id;
		Task persistedTask = taskService.viewTask(id);

		if (persistedTask != null) {
			taskService.deleteTask(id);
			log.info("Deleted task with id = {} ", deleted_id);
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
		} else {
			throw new NoSuchElementException("Task with id {" + deleted_id + "} does not exist!");
		}
	}
	
	@DeleteMapping("/deleteAll")
	@Secured("ROLE_MANAGER")
	public ResponseEntity<Void> deleteAllTasks() {
		
		List<Task> persistedTask = taskService.viewAllTasks();

		if (persistedTask.isEmpty()) {
			throw new NoSuchElementException("No task present..");

		} else {
			taskService.deleteAllTasks();
			log.info("All tasks deleted successfully.");
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);

		}
	}

}

