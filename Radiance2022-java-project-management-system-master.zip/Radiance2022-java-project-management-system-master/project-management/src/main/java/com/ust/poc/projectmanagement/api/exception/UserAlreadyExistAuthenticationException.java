package com.ust.poc.projectmanagement.api.exception;

public class UserAlreadyExistAuthenticationException extends Exception {

	public UserAlreadyExistAuthenticationException(String string) {
		super(string);
	}

}
