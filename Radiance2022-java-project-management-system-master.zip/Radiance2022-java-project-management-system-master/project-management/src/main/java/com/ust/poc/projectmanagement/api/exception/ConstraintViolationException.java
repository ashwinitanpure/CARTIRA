package com.ust.poc.projectmanagement.api.exception;

public class ConstraintViolationException extends RuntimeException {

}
