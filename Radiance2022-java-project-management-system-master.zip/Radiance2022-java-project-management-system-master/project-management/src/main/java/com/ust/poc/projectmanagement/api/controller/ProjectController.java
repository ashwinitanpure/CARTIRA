package com.ust.poc.projectmanagement.api.controller;

import java.util.List;
import java.util.NoSuchElementException;

import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.poc.projectmanagement.api.entity.Project;
import com.ust.poc.projectmanagement.api.entity.Task;
import com.ust.poc.projectmanagement.api.exception.DataIntegrityViolationException;
import com.ust.poc.projectmanagement.api.services.ProjectService;
import com.ust.poc.projectmanagement.api.services.TaskService;

import lombok.extern.slf4j.Slf4j;

@ControllerAdvice
@RestController
@RequestMapping(path = "/project")
@Slf4j
public class ProjectController {
	private static final org.slf4j.Logger log =LoggerFactory.getLogger(JwtController.class);

	@Autowired
	ProjectService projectService;

	@Autowired
	TaskService taskService;

	@PostMapping("/")
	@Secured("ROLE_MANAGER")
	public ResponseEntity<Project> createProject(@Valid @RequestBody Project project) {

		List<Project> persistedProjects = projectService.viewAllProjects();
		for (Project p : persistedProjects) {
			if (project.getTitle().equals(p.getTitle())) {
				log.error("exception as duplicate project found ");
				throw new DataIntegrityViolationException("Project already exists in database!!! ");
			} 
		}
		log.info("Creating project with project details = {} ", project);
		Project newProject = projectService.createProject(project);
		log.info("Project created successfully with project id = {} ", newProject.getId());
		return new ResponseEntity<>(newProject, HttpStatus.CREATED);

	}

	@GetMapping("/{id}")
	@Secured("ROLE_MANAGER")
	public ResponseEntity<Project> viewProject(@PathVariable("id") int id) {

		log.info("Fetching project with project id = {}", id);
		Project persistedProject = projectService.viewProjectById(id);

		if (persistedProject != null) {
			log.info("Project fetched successfully with project id = {}", id);
			return new ResponseEntity<>(persistedProject, HttpStatus.OK);
		} else {
			throw new NoSuchElementException("Project not found with id : " + id);
		}
	}

	@GetMapping("/list")
	@Secured({"ROLE_MANAGER","ROLE_USER"})
	public List<Project> viewAllProjects() {

		log.info("Fetching all projects...");
		List<Project> persistedProject = projectService.viewAllProjects();

		if (persistedProject.isEmpty()) {
			throw new NoSuchElementException("No projects exist in database!!! ");
		} else {
			return persistedProject;
		}
	}

	@PutMapping("/{id}")
	@Secured("ROLE_MANAGER")
	public ResponseEntity<Project> updateProject(@Valid @RequestBody Project project, @PathVariable("id") int id) {

		log.info("Updating project with project id = {}", project.getId());
		Project persistedProject = projectService.viewProjectById(id);

		if (persistedProject != null) {
			persistedProject = projectService.updateProject(project);
			log.info("Project updated successfully with project id = {}", persistedProject.getId());
			return new ResponseEntity<>(persistedProject, HttpStatus.OK);
		} else {
			throw new NoSuchElementException("Project does not exist...");
		}

	}

	@DeleteMapping("/{id}")
	@Secured("ROLE_MANAGER")
	public ResponseEntity<Void> deleteProject(@PathVariable("id") int id) {
		int deleted_id = id;
		Project persistedProject = projectService.viewProjectById(id);

		if (persistedProject != null) {
			projectService.deleteProject(id);
			log.info("Deleted project with id = {} ", deleted_id);
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
		} else {
			throw new NoSuchElementException("Project with id {" + deleted_id + "} does not exist!");
		}
	}

	

	@GetMapping("/tasks/{id}")
	@Secured({"ROLE_MANAGER","ROLE_USER"})
	public ResponseEntity<List<Task>> viewProjectTasks(@PathVariable("id") int id) {

		Project persistedProject = projectService.viewProjectById(id);

		if (persistedProject != null) {
			List<Task> tasks = taskService.viewAllTasksWithProjectId(id);
			if (tasks.isEmpty()) {
				// log.info("This project does not have any tasks");
				throw new NoSuchElementException("No task exist for this project.");

			} else {
				log.info("Tasks under project id = {}", id);
				return ResponseEntity.status(HttpStatus.OK).body(tasks);
			}
		} else {
			throw new NoSuchElementException("Project not found with id : " + id);
		}

	}
}
