package com.ust.poc.projectmanagement.api.controller;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.ust.poc.projectmanagement.api.entity.Jwt;
import com.ust.poc.projectmanagement.api.entity.Token;
import com.ust.poc.projectmanagement.api.exception.InvalidCredentialsException;
import com.ust.poc.projectmanagement.api.exception.UserNotfoundException;
import com.ust.poc.projectmanagement.api.jwt.helper.JwtOperations;
import com.ust.poc.projectmanagement.api.service.CustomUserDetails;



@RestController
public class JwtController {
	
	private static final org.slf4j.Logger log =LoggerFactory.getLogger(JwtController.class);
	
	@Autowired
	private CustomUserDetails customUserService;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private JwtOperations jwtOperations;
	 
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ResponseEntity<?> generateToken(@RequestBody Jwt jwt) throws Exception
	{
		log.info("creadetials to generate jwt token ");
		
		try {
			this.authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(jwt.getUsername(), jwt.getPassword()));
			
		}
		catch(UsernameNotFoundException e)
		{
			log.error("user not found with the given ID: "+jwt.getUsername());
			throw new UserNotfoundException();
			
		}
		catch (BadCredentialsException e) {
			log.error("invalid password or given username (",jwt.getUsername(),")");
			throw new InvalidCredentialsException();
			// TODO: handle exception
		}
		
		UserDetails userDeatils=this.customUserService.loadUserByUsername(jwt.getUsername());
		
		String token=this.jwtOperations.generateToken(userDeatils);
		
		log.info("token generated");
		
		
		return ResponseEntity.ok(new Token(token));
	}

}
